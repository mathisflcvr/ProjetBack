const mysql = require("mysql2/promise");
const { nom } = require("../config.json");

async function query(sql, params){
    const connection = await
}